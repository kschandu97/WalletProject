package com.cg.service;


import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.entity.Account;


public interface AccountOperation {
	public boolean addAccount(Account ob);
	public boolean deleteAccount(Long mobile);
	public boolean updateAccount(Account ob)  ;
	public List<Account> findAccount(Long mobileno);
	public List<Account> getAllAccounts() ;
	public void deleteAll() ;
	public void TransferMoney(Long from, Long to,double amount)  ; 
}

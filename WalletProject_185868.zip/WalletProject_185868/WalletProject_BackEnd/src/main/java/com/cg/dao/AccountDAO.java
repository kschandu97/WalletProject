package com.cg.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.*;


public interface AccountDAO extends JpaRepository<Account,Long> {
	List<Account> findBymobileno(long mobileno);
	
	
//	public boolean addAccount(Account ob);
//	
//	public boolean deleteAccount(Account ob);
//	public Account findAccount(Long mobileno);
//	public Map<Long,Account> getAllAccounts() ;
//    public double TransferMoney(Account from, Account to,double amount) ;
//	boolean updateAccount(Account ob); 

}

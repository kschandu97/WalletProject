package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.IWalletDao;
import com.cg.exception.WalletException;
@Service
public class WalletServiceImpl implements IWalletService {
	@Autowired
	IWalletDao iWalletDao;

	public Customer createAccount(Customer customer) throws WalletException  {
		return iWalletDao.createAccount(customer);
	}

	public double showBalance(int customerId) throws WalletException {
		return iWalletDao.showBalance(customerId);
	}

	public boolean deposit(int customerId, double amount) throws WalletException{
		return iWalletDao.deposit(customerId, amount);
	}

	public boolean withdraw(int customerId, double amount) throws WalletException   {
		return iWalletDao.withdraw(customerId, amount);
	}

	public boolean fundTransfer(int customerId, int customId,double amount) throws WalletException  {
		return iWalletDao.fundTransfer(customerId, customId, amount);
	}

	public List<Transaction> printTransaction(int customerId) throws WalletException  {
		System.out.println("service"+customerId);
		return iWalletDao.printTransaction(customerId);
	}

	@Override
	public List<Customer> viewAll() {
		return iWalletDao.viewAll();
	}

	@Override
	public boolean validateEmail(String email) {
		return iWalletDao.validateEmail(email);
	}


}
